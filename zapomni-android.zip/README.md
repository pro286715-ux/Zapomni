# Запомни: сборка APK

1. Создайте репозиторий на github.com (кнопка New).
2. Добавьте в корень два файла: index.html и .github/workflows/build.yml
   (Add file -> Create new file, в имени можно писать путь со слешами).
3. Откройте вкладку Actions: сборка стартует сама после коммита (3-5 минут).
4. Откройте Releases справа на главной странице репозитория и скачайте zapomni.apk.
5. Разрешите установку из неизвестных источников и откройте файл.

В Settings -> Actions -> General -> Workflow permissions должно быть Read and write.
